import csv
import hmac
import io
import os
import secrets
from datetime import date
from functools import wraps

import psycopg
from flask import Flask, Response, abort, flash, redirect, render_template, request, session, url_for
from psycopg.rows import dict_row, tuple_row

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.getenv("LAB15_SECRET_KEY") or secrets.token_hex(32),
    SESSION_COOKIE_SAMESITE="Lax",
)
DATABASE_URL = os.getenv("LAB15_DATABASE_URL", "postgresql://postgres@localhost:5432/postgres")
LOGIN = os.getenv("LAB15_LOGIN", "demo")
PASSWORD = os.getenv("LAB15_PASSWORD", "demo")


def connect():
    return psycopg.connect(DATABASE_URL, row_factory=dict_row)


@app.context_processor
def form_token():
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(32)
    return {"csrf_token": session["csrf"]}


@app.before_request
def check_csrf():
    if request.method == "POST":
        expected = session.get("csrf")
        supplied = request.form.get("csrf", "")
        if not expected or not hmac.compare_digest(expected.encode(), supplied.encode()):
            abort(400, "Форма устарела. Обновите страницу и повторите попытку.")


def login_required(view):
    @wraps(view)
    def protected(*args, **kwargs):
        if not session.get("login"):
            return redirect(url_for("login"))
        return view(*args, **kwargs)

    return protected


@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("login"):
        return redirect(url_for("students"))
    if request.method == "POST":
        username = request.form.get("login", "")
        password = request.form.get("password", "")
        if (hmac.compare_digest(username.encode(), LOGIN.encode())
                and hmac.compare_digest(password.encode(), PASSWORD.encode())):
            session.clear()
            session["login"] = username
            return redirect(url_for("students"))
        return render_template("login.html", error="Неверный логин или пароль."), 401
    return render_template("login.html")


@app.post("/logout")
@login_required
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.get("/")
@login_required
def students():
    search = request.args.get("q", "").strip()
    with connect() as db:
        rows = db.execute(
            """
            SELECT s."StudentID" AS id,
                   concat_ws(' ', s."LastName", s."FirstName", s."MiddleName") AS name,
                   st."Status" AS status,
                   f."Type" AS funding,
                   string_agg(g."Name", ', ' ORDER BY g."Name") AS groups
            FROM public."Student" s
            JOIN public."Status" st ON st."ID" = s."StatusID"
            JOIN public."FundingType" f ON f."ID" = s."FundingTypeID"
            LEFT JOIN public."StudentGroup" sg ON sg."StudentID" = s."StudentID"
            LEFT JOIN public."Group" g ON g."ID" = sg."GroupID"
            WHERE strpos(lower(concat_ws(' ', s."LastName", s."FirstName", s."MiddleName")),
                         lower(%s)) > 0 OR %s = ''
            GROUP BY s."StudentID", st."Status", f."Type"
            ORDER BY s."LastName", s."FirstName", s."StudentID"
            """, (search, search),
        ).fetchall()
    return render_template("students.html", students=rows, search=search)



CATALOGS = {
    "groups": (
        "Группы", ("Группа", "Специальность", "Курс", "Форма обучения", "Студентов"),
        """
        SELECT g."ID", g."Name", sp."Name", g."StudyYear", sf."Name", count(sg."StudentID")
        FROM public."Group" g
        JOIN public."Specialties" sp ON sp."ID" = g."SpecialtyID"
        JOIN public."StudyFormat" sf ON sf."ID" = g."StudyFormatID"
        LEFT JOIN public."StudentGroup" sg ON sg."GroupID" = g."ID"
        GROUP BY g."ID", sp."Name", sf."Name"
        ORDER BY g."Name", g."ID"
        """,
    ),
    "teachers": (
        "Преподаватели", ("ФИО", "Кафедра", "Должность", "Учёная степень"),
        """
        SELECT t."ID", concat_ws(' ', t."LastName", t."FirstName", t."MiddleName"),
               dep."Name", p."Name", deg."Name"
        FROM public."Teacher" t
        JOIN public."Department" dep ON dep."ID" = t."DepartmentID"
        JOIN public."Positions" p ON p."ID" = t."PositionID"
        LEFT JOIN public."Degrees" deg ON deg."ID" = t."DegreeID"
        ORDER BY t."LastName", t."FirstName", t."ID"
        """,
    ),
    "disciplines": (
        "Дисциплины", ("Название", "Кафедра", "Виды занятий и часы", "Всего часов"),
        """
        SELECT d."Name", dep."Name",
               string_agg(concat(ty."Name", ' — ', dh."Hours", ' ч'), ', ' ORDER BY ty."ID")
                   FILTER (WHERE dh."ID" IS NOT NULL),
               coalesce(sum(dh."Hours"), 0)
        FROM public."Discipline" d
        JOIN public."Department" dep ON dep."ID" = d."DepartmentID"
        LEFT JOIN public."DisciplineHours" dh ON dh."DisciplineID" = d."ID"
        LEFT JOIN public."Types" ty ON ty."ID" = dh."TypeID"
        GROUP BY d."ID", dep."Name"
        ORDER BY d."Name", d."ID"
        """,
    ),
}


@app.get("/catalog/<section>")
@login_required
def catalog(section):
    if section not in CATALOGS:
        abort(404)
    title, columns, query = CATALOGS[section]
    with connect() as db, db.cursor(row_factory=tuple_row) as cursor:
        rows = cursor.execute(query).fetchall()
    detail = {"groups": ("group_card", "group_id"), "teachers": ("teacher_card", "teacher_id")}.get(section)
    return render_template("catalog.html", title=title, columns=columns, rows=rows, detail=detail)


def student_values(form):
    last, first, middle = (form.get(key, "").strip() for key in ("last", "first", "middle"))
    if not first or not last or max(len(first), len(last), len(middle)) > 100:
        raise ValueError("Укажите имя и фамилию. Максимальная длина каждого поля — 100 символов.")
    start = None
    if form.get("start"):
        try:
            start = date.fromisoformat(form["start"])
        except ValueError as exc:
            raise ValueError("Укажите корректную дату зачисления.") from exc
    return last, first, middle or None, positive_id(form, "funding"), start, positive_id(form, "status")


def positive_id(form, field):
    try:
        value = int(form.get(field, ""))
    except ValueError as exc:
        raise ValueError("Выберите значение из списка.") from exc
    if not 1 <= value <= 2147483647:
        raise ValueError("Выберите значение из списка.")
    return value


@app.route("/students/new", defaults={"student_id": None}, methods=["GET", "POST"])
@app.route("/students/<int:student_id>", methods=["GET", "POST"])
@login_required
def student(student_id):
    error = None
    if request.method == "POST":
        try:
            values = student_values(request.form)
            # Psycopg фиксирует транзакцию при выходе из with и откатывает её при ошибке.
            with connect() as db:
                if student_id is None:
                    group_id = positive_id(request.form, "group")
                    inserted = db.execute(
                        """
                        INSERT INTO public."Student"
                          ("LastName", "FirstName", "MiddleName", "FundingTypeID", "StartDate", "StatusID")
                        VALUES (%s, %s, %s, %s, %s, %s) RETURNING "StudentID" AS id
                        """, values,
                    ).fetchone()
                    db.execute(
                        'INSERT INTO public."StudentGroup" ("StudentID", "GroupID") VALUES (%s, %s)',
                        (inserted["id"], group_id),
                    )
                    saved_id = inserted["id"]
                else:
                    updated = db.execute(
                        """
                        UPDATE public."Student"
                        SET ("LastName", "FirstName", "MiddleName", "FundingTypeID", "StartDate", "StatusID")
                          = (%s, %s, %s, %s, %s, %s)
                        WHERE "StudentID" = %s
                        """, (*values, student_id),
                    )
                    if not updated.rowcount:
                        abort(404)
                    saved_id = student_id
            flash("Данные студента сохранены.", "success")
            return redirect(url_for("student", student_id=saved_id))
        except ValueError as exc:
            error = str(exc)
        except psycopg.IntegrityError:
            error = "Проверьте выбранные группу, финансирование и статус."
        except psycopg.errors.RaiseException:
            error = "Проверьте дату зачисления. Для нового студента она должна быть сегодняшней или будущей."

    with connect() as db:
        funding = db.execute(
            'SELECT "ID" AS id, "Type" AS name FROM public."FundingType" ORDER BY "ID"'
        ).fetchall()
        statuses = db.execute(
            'SELECT "ID" AS id, "Status" AS name FROM public."Status" ORDER BY "ID"'
        ).fetchall()
        groups = db.execute(
            'SELECT "ID" AS id, "Name" AS name FROM public."Group" ORDER BY "Name", "ID"'
        ).fetchall()
        data, memberships, grades = {}, [], []
        if student_id is not None:
            data = db.execute(
                """
                SELECT "LastName" AS last, "FirstName" AS first, "MiddleName" AS middle,
                       "StartDate" AS start, "StatusID" AS status, "FundingTypeID" AS funding
                FROM public."Student" WHERE "StudentID" = %s
                """, (student_id,),
            ).fetchone()
            if data is None:
                abort(404)
            memberships = db.execute(
                """
                SELECT g."ID" AS id, g."Name" AS name
                FROM public."StudentGroup" sg JOIN public."Group" g ON g."ID" = sg."GroupID"
                WHERE sg."StudentID" = %s ORDER BY g."Name", g."ID"
                """, (student_id,),
            ).fetchall()
            grades = db.execute(
                """
                SELECT a."Date" AS date, d."Name" AS discipline, at."Name" AS assessment, a."Grade" AS grade
                FROM public."Attempt" a
                JOIN public."Assessment" x ON x."ID" = a."AssessmentID"
                JOIN public."AssessmentType" at ON at."ID" = x."AssessmentTypeID"
                JOIN public."GroupDiscipline" gd ON gd."ID" = x."GroupDisciplineID"
                JOIN public."Discipline" d ON d."ID" = gd."DisciplineID"
                WHERE a."StudentID" = %s ORDER BY a."Date" DESC, a."ID" DESC
                """, (student_id,),
            ).fetchall()
    return render_template("student.html", student_id=student_id, data=request.form if error else data,
                           error=error, funding=funding, statuses=statuses, groups=groups,
                           memberships=memberships, grades=grades), 400 if error else 200


@app.post("/students/<int:student_id>/transfer")
@login_required
def transfer(student_id):
    try:
        old = positive_id(request.form, "old_group")
        new = positive_id(request.form, "new_group")
        if old == new:
            raise ValueError("Выберите другую группу.")
        with connect() as db:
            with db.transaction():
                exists = db.execute(
                    'SELECT 1 FROM public."Student" WHERE "StudentID" = %s FOR UPDATE',
                    (student_id,),
                ).fetchone()
                if not exists:
                    abort(404)
                removed = db.execute(
                    """
                    DELETE FROM public."StudentGroup"
                    WHERE "StudentID" = %s AND "GroupID" = %s
                    """, (student_id, old),
                )
                if removed.rowcount != 1:
                    raise ValueError("Студент уже не числится в исходной группе.")
                db.execute(
                    'INSERT INTO public."StudentGroup" ("StudentID", "GroupID") VALUES (%s, %s)',
                    (student_id, new),
                )
        flash("Перевод выполнен.", "success")
    except ValueError as exc:
        flash(str(exc), "error")
    except psycopg.errors.UniqueViolation:
        flash("Студент уже в выбранной группе. Перевод отменён.", "error")
    except psycopg.errors.ForeignKeyViolation:
        flash("Группа назначения не найдена. Перевод отменён.", "error")
    return redirect(url_for("student", student_id=student_id))


def csv_download(filename, columns, rows):
    output = io.StringIO(newline="")
    writer = csv.writer(output, delimiter=";")
    writer.writerow(columns)
    for row in rows:
        writer.writerow(
            "'" + value if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@"))
            else value
            for value in row
        )
    return Response("\ufeff" + output.getvalue(), content_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@app.get("/groups/<int:group_id>")
@login_required
def group_card(group_id):
    with connect() as db:
        group = db.execute(
            """
            SELECT g."ID" AS id, g."Name" AS name, g."StudyYear" AS year,
                   sp."Name" AS specialty, sf."Name" AS study_format
            FROM public."Group" g
            JOIN public."Specialties" sp ON sp."ID" = g."SpecialtyID"
            JOIN public."StudyFormat" sf ON sf."ID" = g."StudyFormatID"
            WHERE g."ID" = %s
            """, (group_id,),
        ).fetchone()
        if not group:
            abort(404)
        roster = db.execute(
            """
            SELECT s."StudentID" AS id,
                   concat_ws(' ', s."LastName", s."FirstName", s."MiddleName") AS name,
                   f."Type" AS funding, st."Status" AS status
            FROM public."StudentGroup" sg
            JOIN public."Student" s ON s."StudentID" = sg."StudentID"
            JOIN public."FundingType" f ON f."ID" = s."FundingTypeID"
            JOIN public."Status" st ON st."ID" = s."StatusID"
            WHERE sg."GroupID" = %s
            ORDER BY s."LastName", s."FirstName", s."StudentID"
            """, (group_id,),
        ).fetchall()
        if request.args.get("export") == "csv":
            return csv_download(f"group-{group_id}.csv", ("ID", "ФИО", "Финансирование", "Статус"),
                                ((r["id"], r["name"], r["funding"], r["status"]) for r in roster))
        curriculum = db.execute(
            """
            SELECT gd."ID" AS id, gd."SemesterNum" AS semester, d."Name" AS discipline,
                   hours.details AS hours
            FROM public."GroupDiscipline" gd
            JOIN public."Discipline" d ON d."ID" = gd."DisciplineID"
            LEFT JOIN LATERAL (
                SELECT string_agg(concat(ty."Name", ' — ', dh."Hours", ' ч'), ', ' ORDER BY ty."ID") AS details
                FROM public."DisciplineHours" dh
                JOIN public."Types" ty ON ty."ID" = dh."TypeID"
                WHERE dh."DisciplineID" = d."ID"
            ) hours ON true
            WHERE gd."GroupID" = %s
            ORDER BY gd."SemesterNum", d."Name", gd."ID"
            """, (group_id,),
        ).fetchall()
        assessments = db.execute(
            """
            SELECT a."ID" AS id, a."GroupDisciplineID" AS discipline_id, ty."Name" AS name
            FROM public."Assessment" a
            JOIN public."GroupDiscipline" gd ON gd."ID" = a."GroupDisciplineID"
            JOIN public."AssessmentType" ty ON ty."ID" = a."AssessmentTypeID"
            WHERE gd."GroupID" = %s ORDER BY ty."Name", a."ID"
            """, (group_id,),
        ).fetchall()
    by_discipline = {}
    for assessment in assessments:
        by_discipline.setdefault(assessment["discipline_id"], []).append(assessment)
    return render_template("group.html", group=group, roster=roster, curriculum=curriculum,
                           assessments=by_discipline)


@app.get("/teachers/<int:teacher_id>")
@login_required
def teacher_card(teacher_id):
    with connect() as db:
        teacher = db.execute(
            """
            SELECT concat_ws(' ', t."LastName", t."FirstName", t."MiddleName") AS name,
                   dep."Name" AS department, p."Name" AS position, deg."Name" AS degree
            FROM public."Teacher" t
            JOIN public."Department" dep ON dep."ID" = t."DepartmentID"
            JOIN public."Positions" p ON p."ID" = t."PositionID"
            LEFT JOIN public."Degrees" deg ON deg."ID" = t."DegreeID"
            WHERE t."ID" = %s
            """, (teacher_id,),
        ).fetchone()
        if not teacher:
            abort(404)
        classes = db.execute(
            """
            SELECT g."ID" AS group_id, g."Name" AS group_name, gd."SemesterNum" AS semester,
                   d."Name" AS discipline, ty."Name" AS kind
            FROM public."Teaches" t
            JOIN public."GroupDiscipline" gd ON gd."ID" = t."GroupDisciplineID"
            JOIN public."Discipline" d ON d."ID" = gd."DisciplineID"
            JOIN public."Group" g ON g."ID" = gd."GroupID"
            JOIN public."Types" ty ON ty."ID" = t."TypeID"
            WHERE t."TeacherID" = %s
            ORDER BY d."Name", g."Name", gd."SemesterNum", ty."Name"
            """, (teacher_id,),
        ).fetchall()
    return render_template("teacher.html", teacher=teacher, classes=classes)


def save_grades(assessment_id):
    teacher_id = positive_id(request.form, "teacher")
    grades = {}
    for key, value in request.form.items():
        if key.startswith("grade_") and value.strip():
            student_id = positive_id({"student": key.removeprefix("grade_")}, "student")
            try:
                grade = int(value)
            except ValueError as exc:
                raise ValueError(f"У студента №{student_id} оценка должна быть целым числом.") from exc
            if not 1 <= grade <= 10:
                raise ValueError(f"У студента №{student_id} оценка должна быть от 1 до 10.")
            grades[student_id] = grade
    if not grades:
        raise ValueError("Введите хотя бы одну оценку.")

    with connect() as db, db.transaction():
        db.execute("SET LOCAL search_path TO public")
        # Блокировка аттестации сериализует массовые записи из этого приложения.
        assessment = db.execute(
            'SELECT "ID" FROM public."Assessment" WHERE "ID" = %s FOR NO KEY UPDATE', (assessment_id,),
        ).fetchone()
        if not assessment:
            abort(404)
        for student_id, grade in sorted(grades.items()):
            db.execute(
                'SELECT 1 FROM public."Student" WHERE "StudentID" = %s FOR UPDATE', (student_id,),
            ).fetchone()
            try:
                db.execute(
                    """
                    INSERT INTO public."Attempt" ("AssessmentID", "StudentID", "TeacherID", "Grade", "Date")
                    VALUES (%s, %s, %s, %s, CURRENT_DATE)
                    """, (assessment_id, student_id, teacher_id, grade),
                )
            except psycopg.errors.RaiseException as exc:
                raise ValueError(f"Студент №{student_id}. {exc.diag.message_primary}") from exc
    return len(grades)


@app.route("/assessments/<int:assessment_id>", methods=["GET", "POST"])
@login_required
def gradebook(assessment_id):
    error = None
    if request.method == "POST":
        try:
            saved = save_grades(assessment_id)
            flash(f"Сохранено оценок: {saved}.", "success")
            return redirect(url_for("gradebook", assessment_id=assessment_id))
        except ValueError as exc:
            error = f"Ведомость не сохранена. {exc}"
        except psycopg.IntegrityError:
            error = "Ведомость не сохранена. Проверьте преподавателя и состав группы."

    with connect() as db:
        assessment = db.execute(
            """
            SELECT a."MaxAttempts" AS max_attempts, gd."ID" AS group_discipline_id,
                   g."ID" AS group_id, g."Name" AS group_name, gd."SemesterNum" AS semester,
                   d."Name" AS discipline, ty."Name" AS kind
            FROM public."Assessment" a
            JOIN public."GroupDiscipline" gd ON gd."ID" = a."GroupDisciplineID"
            JOIN public."Group" g ON g."ID" = gd."GroupID"
            JOIN public."Discipline" d ON d."ID" = gd."DisciplineID"
            JOIN public."AssessmentType" ty ON ty."ID" = a."AssessmentTypeID"
            WHERE a."ID" = %s
            """, (assessment_id,),
        ).fetchone()
        if not assessment:
            abort(404)
        rows = db.execute(
            """
            SELECT s."StudentID" AS id,
                   concat_ws(' ', s."LastName", s."FirstName", s."MiddleName") AS name,
                   history.grades, cardinality(history.grades) AS attempts, history.grades[1] AS latest
            FROM public."StudentGroup" sg
            JOIN public."Student" s ON s."StudentID" = sg."StudentID"
            CROSS JOIN LATERAL (
                SELECT ARRAY(
                    SELECT a."Grade" FROM public."Attempt" a
                    WHERE a."AssessmentID" = %s AND a."StudentID" = s."StudentID"
                    ORDER BY a."Date" DESC, a."ID" DESC
                ) AS grades
            ) history
            WHERE sg."GroupID" = %s
            ORDER BY s."LastName", s."FirstName", s."StudentID"
            """, (assessment_id, assessment["group_id"]),
        ).fetchall()
        if request.args.get("export") == "csv":
            return csv_download(
                f"assessment-{assessment_id}.csv", ("ID", "ФИО", "Попытки по порядку", "Последняя оценка"),
                ((r["id"], r["name"], ", ".join(map(str, reversed(r["grades"]))), r["latest"]) for r in rows),
            )
        teachers = db.execute(
            """
            SELECT DISTINCT t."ID" AS id, concat_ws(' ', t."LastName", t."FirstName", t."MiddleName") AS name
            FROM public."Teaches" tc
            JOIN public."Teacher" t ON t."ID" = tc."TeacherID"
            WHERE tc."GroupDisciplineID" = %s ORDER BY name, id
            """, (assessment["group_discipline_id"],),
        ).fetchall()
    latest = [row["latest"] for row in rows if row["latest"] is not None]
    missing = [row for row in rows if not row["attempts"]]
    retakes = [row for row in rows if row["attempts"] > 1]
    average = f"{sum(latest) / len(latest):.2f}" if latest else "—"
    return render_template("gradebook.html", assessment=assessment, assessment_id=assessment_id,
                           rows=rows, teachers=teachers, error=error, average=average,
                           missing=missing, retakes=retakes), 400 if error else 200


@app.errorhandler(psycopg.OperationalError)
def database_unavailable(_error):
    return render_template("error.html", title="База недоступна",
                           message="Проверьте, что PostgreSQL запущен и параметры LAB15_DATABASE_URL верны."), 503


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5015)
